package main

import (
    "log"

    "github.com/joho/godotenv"
    "golang_scraper_stack_pro/internal/scraper"
    "golang_scraper_stack_pro/pkg/logger"
)

func main() {
    _ = godotenv.Load()

    log.Println("Starting Stealth Golang Scraper 2025...")

    logger.InitLogger()

    scraper.Run()
}
