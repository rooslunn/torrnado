### Скелет Golang-скрейпера 2025т:

- Proxy Rotation (чтение списка прокси из файла, рандомизация)
- Stealth Headless Chrome через [Rod](https://go-rod.github.io/)
- Асинхронный воркер для обработки результатов
- Логирование через [Zap](https://github.com/uber-go/zap)
- Поддержка .env для конфигурации (через github.com/joho/godotenv)

