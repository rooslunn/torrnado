package parser

import "strings"

func CleanHTML(html string) string {
    return strings.TrimSpace(html)
}