package scraper

import (
    "context"
    "log"
    "time"

    "github.com/go-rod/rod"
    "github.com/go-rod/rod/lib/launcher"
)

func Run() {
    proxies, err := LoadProxies("configs/proxies.txt")
    if err != nil {
        log.Fatal("Failed to load proxies:", err)
    }

    proxy := GetRandomProxy(proxies)
    log.Println("Using proxy:", proxy)

    url := launcher.New().
        Proxy(proxy).
        Headless(true).
        MustLaunch()

    browser := rod.New().ControlURL(url).MustConnect()
    defer browser.MustClose()

    page := browser.MustPage("https://httpbin.org/ip")
    page.MustWaitLoad()
    html := page.MustHTML()

    log.Println("Fetched HTML length:", len(html))
}
