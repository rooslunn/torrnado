package scraper

import (
    "bufio"
    "math/rand"
    "os"
    "strings"
    "time"
)

func LoadProxies(filePath string) ([]string, error) {
    file, err := os.Open(filePath)
    if err != nil {
        return nil, err
    }
    defer file.Close()

    var proxies []string
    scanner := bufio.NewScanner(file)
    for scanner.Scan() {
        proxies = append(proxies, strings.TrimSpace(scanner.Text()))
    }
    return proxies, nil
}

func GetRandomProxy(proxies []string) string {
    rand.Seed(time.Now().UnixNano())
    return proxies[rand.Intn(len(proxies))]
}
