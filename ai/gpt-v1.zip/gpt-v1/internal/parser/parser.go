package parser

import (
    "strings"
)

func CleanText(input string) string {
    return strings.TrimSpace(input)
}
