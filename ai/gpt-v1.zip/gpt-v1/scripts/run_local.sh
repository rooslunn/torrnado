#!/bin/bash
go build -o scraper ./cmd/scraper
./scraper --config configs/config.yaml
